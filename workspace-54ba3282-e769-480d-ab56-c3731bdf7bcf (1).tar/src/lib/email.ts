import nodemailer from 'nodemailer'

// Create a transporter using Gmail SMTP
const createTransporter = () => {
  return nodemailer.createTransporter({
    host: 'smtp.gmail.com',
    port: 587,
    secure: false, // true for 465, false for other ports
    auth: {
      user: process.env.GMAIL_USER, // Your Gmail address
      pass: process.env.GMAIL_APP_PASSWORD, // Your Gmail app password
    },
  })
}

// Email templates
const emailTemplates = {
  welcome: (userName: string, userEmail: string) => ({
    subject: '🎉 Welcome to Tourism India - Your Adventure Begins!',
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Welcome to Tourism India</title>
        <style>
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #ff9933, #138808); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
          .logo { font-size: 48px; margin-bottom: 10px; }
          .btn { display: inline-block; background: linear-gradient(135deg, #ff9933, #138808); color: white; padding: 12px 30px; text-decoration: none; border-radius: 25px; margin: 20px 0; }
          .feature { background: white; padding: 20px; margin: 10px 0; border-radius: 8px; border-left: 4px solid #ff9933; }
          .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo">🇮🇳</div>
            <h1>Welcome to Tourism India!</h1>
            <p>Your incredible Indian adventure starts now</p>
          </div>
          
          <div class="content">
            <h2>🙏 Namaste, ${userName}!</h2>
            <p>Thank you for joining Tourism India! We're thrilled to have you as part of our travel community.</p>
            
            <div class="feature">
              <h3>🎯 What's Next?</h3>
              <p>Explore our 28 amazing states, discover hidden gems, connect with fellow travelers, and get personalized AI travel assistance.</p>
            </div>
            
            <div class="feature">
              <h3>🌟 Your Account Benefits</h3>
              <ul>
                <li>✈️ Book hotels, guides, and experiences</li>
                <li>🗺️ Explore detailed state information</li>
                <li>👥 Connect with solo travelers</li>
                <li>🤖 Get AI travel recommendations</li>
                <li>📍 Share and discover hidden gems</li>
              </ul>
            </div>
            
            <div style="text-align: center;">
              <a href="http://localhost:3000" class="btn">Start Exploring India</a>
            </div>
            
            <div class="feature">
              <h3>📧 Need Help?</h3>
              <p>Our support team is here to help you plan your perfect Indian journey. Reply to this email anytime!</p>
            </div>
          </div>
          
          <div class="footer">
            <p>🇮🇳 Tourism India - Your Gateway to Incredible India</p>
            <p>This email was sent to ${userEmail}</p>
          </div>
        </div>
      </body>
      </html>
    `
  }),

  bookingConfirmation: (userName: string, userEmail: string, bookingDetails: any) => ({
    subject: `🎉 Booking Confirmed - ${bookingDetails.itemName} in ${bookingDetails.stateName}`,
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Booking Confirmation - Tourism India</title>
        <style>
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #ff9933, #138808); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
          .logo { font-size: 48px; margin-bottom: 10px; }
          .booking-details { background: white; padding: 20px; margin: 20px 0; border-radius: 8px; border: 2px solid #ff9933; }
          .detail-row { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #eee; }
          .detail-row:last-child { border-bottom: none; }
          .total { font-size: 18px; font-weight: bold; color: #138808; }
          .footer { text-align: center; margin-top: 30px; color: #666; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="logo">🇮🇳</div>
            <h1>Booking Confirmed!</h1>
            <p>Your Indian adventure is all set</p>
          </div>
          
          <div class="content">
            <h2>🎉 Congratulations, ${userName}!</h2>
            <p>Your booking has been confirmed. Here are your details:</p>
            
            <div class="booking-details">
              <h3>📋 Booking Information</h3>
              <div class="detail-row">
                <strong>Booking ID:</strong>
                <span>#TOUR${Date.now()}</span>
              </div>
              <div class="detail-row">
                <strong>Item:</strong>
                <span>${bookingDetails.itemName}</span>
              </div>
              <div class="detail-row">
                <strong>Location:</strong>
                <span>${bookingDetails.location}</span>
              </div>
              <div class="detail-row">
                <strong>Date:</strong>
                <span>${bookingDetails.date}</span>
              </div>
              <div class="detail-row">
                <strong>Guests:</strong>
                <span>${bookingDetails.guests}</span>
              </div>
              <div class="detail-row">
                <strong>Duration:</strong>
                <span>${bookingDetails.duration || 'As per booking'}</span>
              </div>
              ${bookingDetails.specialRequests ? `
              <div class="detail-row">
                <strong>Special Requests:</strong>
                <span>${bookingDetails.specialRequests}</span>
              </div>
              ` : ''}
              <div class="detail-row total">
                <strong>Total Amount:</strong>
                <span>₹${bookingDetails.totalPrice}</span>
              </div>
            </div>
            
            <div style="background: white; padding: 20px; margin: 20px 0; border-radius: 8px; border-left: 4px solid #138808;">
              <h3>📧 What's Next?</h3>
              <ul>
                <li>✅ You'll receive a reminder 24 hours before your booking</li>
                <li>✅ Save this email for your records</li>
                <li>✅ Contact us if you need to make any changes</li>
                <li>✅ Check your email for updates and notifications</li>
              </ul>
            </div>
            
            <div style="background: #fff3cd; padding: 15px; margin: 20px 0; border-radius: 8px; border-left: 4px solid #ffc107;">
              <h3>📞 Important Information</h3>
              <p><strong>Contact for Support:</strong> support@tourismindia.com<br>
              <strong>Emergency Helpline:</strong> +91-XXXXXXXXXX<br>
              <strong>WhatsApp Support:</strong> +91-XXXXXXXXXX</p>
            </div>
          </div>
          
          <div class="footer">
            <p>🇮🇳 Tourism India - Your Gateway to Incredible India</p>
            <p>Booking ID: #TOUR${Date.now()} | This email was sent to ${userEmail}</p>
          </div>
        </div>
      </body>
      </html>
    `
  })
}

// Send email function
export const sendEmail = async (to: string, template: keyof typeof emailTemplates, data: any) => {
  try {
    const transporter = createTransporter()
    const emailData = emailTemplates[template](data.userName || data.name, to)
    
    // Add dynamic data to template
    let html = emailData.html
    if (template === 'bookingConfirmation') {
      Object.keys(data).forEach(key => {
        html = html.replace(new RegExp(`\\$\\{${key}\\}`, 'g'), data[key])
      })
    }

    const mailOptions = {
      from: `"Tourism India" <${process.env.GMAIL_USER}>`,
      to,
      subject: emailData.subject,
      html: html
    }

    await transporter.sendMail(mailOptions)
    console.log(`Email sent successfully to ${to}`)
    return true
  } catch (error) {
    console.error('Error sending email:', error)
    return false
  }
}

// Test email configuration
export const testEmailConfig = async () => {
  try {
    const transporter = createTransporter()
    await transporter.verify()
    console.log('Email server is ready to send messages')
    return true
  } catch (error) {
    console.error('Email configuration error:', error)
    return false
  }
}