import { Server } from 'socket.io';

export const setupSocket = (io: Server) => {
  io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);
    
    // Handle chat messages
    socket.on('chat-message', (msg: { id: string; content: string; sender: string; timestamp: Date }) => {
      // Broadcast message to all connected clients
      io.emit('chat-message', {
        id: msg.id,
        content: msg.content,
        sender: msg.sender,
        timestamp: msg.timestamp
      });
    });

    // Handle disconnect
    socket.on('disconnect', () => {
      console.log('Client disconnected:', socket.id);
    });

    // Send welcome message
    socket.emit('chat-message', {
      id: 'welcome-' + Date.now(),
      content: 'Welcome to the Solo Traveller Community Chat! 🌍',
      sender: 'System',
      timestamp: new Date()
    });
  });
};