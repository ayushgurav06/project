'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { MapPin, Users, Calendar, Star, Search, Menu, X, LogOut, UserPlus, Brain, MessageCircle, CreditCard, Shield, Home, Settings } from 'lucide-react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'

const indianStates = [
  { id: 1, name: 'Rajasthan', description: 'Land of Kings - Desert forts, palaces, and vibrant culture', image: '/states/rajasthan.jpg', color: 'bg-orange-100', slug: 'rajasthan' },
  { id: 2, name: 'Kerala', description: 'God\'s Own Country - Backwaters, beaches, and Ayurveda', image: '/states/kerala.jpg', color: 'bg-green-100', slug: 'kerala' },
  { id: 3, name: 'Goa', description: 'Beach Paradise - Sun, sand, and Portuguese heritage', image: '/states/goa.jpg', color: 'bg-blue-100', slug: 'goa' },
  { id: 4, name: 'Uttar Pradesh', description: 'Heart of India - Taj Mahal, Ganges, and spiritual centers', image: '/states/uttar-pradesh.jpg', color: 'bg-yellow-100', slug: 'uttar-pradesh' },
  { id: 5, name: 'Maharashtra', description: 'Land of Warriors - Mumbai caves, beaches, and Bollywood', image: '/states/maharashtra.jpg', color: 'bg-purple-100', slug: 'maharashtra' },
  { id: 6, name: 'Tamil Nadu', description: 'Temple State - Ancient Dravidian architecture and culture', image: '/states/tamil-nadu.jpg', color: 'bg-red-100', slug: 'tamil-nadu' },
  { id: 7, name: 'Himachal Pradesh', description: 'Land of Gods - Himalayan mountains and adventure sports', image: '/states/himachal-pradesh.jpg', color: 'bg-teal-100', slug: 'himachal-pradesh' },
  { id: 8, name: 'West Bengal', description: 'Cultural Capital - Art, literature, and colonial heritage', image: '/states/west-bengal.jpg', color: 'bg-pink-100', slug: 'west-bengal' },
  { id: 9, name: 'Gujarat', description: 'Land of Legends - Gir lions, white desert, and business hub', image: '/states/gujarat.jpg', color: 'bg-amber-100', slug: 'gujarat' },
  { id: 10, name: 'Madhya Pradesh', description: 'Heart of India - Wildlife, temples, and tribal culture', image: '/states/madhya-pradesh.jpg', color: 'bg-lime-100', slug: 'madhya-pradesh' },
  { id: 11, name: 'Karnataka', description: 'Silicon Valley - Gardens, palaces, and IT hub', image: '/states/karnataka.jpg', color: 'bg-cyan-100', slug: 'karnataka' },
  { id: 12, name: 'Delhi', description: 'Capital Territory - Mughal heritage and modern metropolis', image: '/states/delhi.jpg', color: 'bg-indigo-100', slug: 'delhi' }
]

export default function HomePage() {
  const [searchTerm, setSearchTerm] = useState('')
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [user, setUser] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    // Check if user is logged in
    const userData = localStorage.getItem('user') || sessionStorage.getItem('user')
    if (userData) {
      setUser(JSON.parse(userData))
      setIsLoggedIn(true)
    } else {
      // If not logged in, redirect to login page
      router.push('/')
    }
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem('user')
    sessionStorage.removeItem('user')
    setIsLoggedIn(false)
    setUser(null)
    router.push('/')
  }

  const filteredStates = indianStates.filter(state =>
    state.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    state.description.toLowerCase().includes(searchTerm.toLowerCase())
  )

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-green-50">
      {/* Navigation Header */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-orange-200 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-green-600 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-xl">🇮🇳</span>
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-green-600 bg-clip-text text-transparent">
                Tourism India
              </h1>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-6">
              <Link href="/home" className="text-gray-700 hover:text-orange-600 transition-colors">Home</Link>
              <Link href="/live-like-local" className="text-gray-700 hover:text-orange-600 transition-colors">Live Like Local</Link>
              <Link href="/community" className="text-gray-700 hover:text-orange-600 transition-colors">Community</Link>
              <Link href="/ai-assistant" className="text-gray-700 hover:text-orange-600 transition-colors">AI Assistant</Link>
              <div className="flex items-center space-x-2">
                <Button variant="outline" className="border-orange-300 text-orange-600 hover:bg-orange-50">
                  <Shield className="w-4 h-4 mr-2" />
                  {user?.name || 'Dashboard'}
                </Button>
                {user?.email === 'ayushgurav0608@gmail.com' && user?.role === 'admin' && (
                  <Link href="/admin">
                    <Button variant="outline" className="border-purple-300 text-purple-600 hover:bg-purple-50">
                      <Settings className="w-4 h-4 mr-2" />
                      Admin
                    </Button>
                  </Link>
                )}
                <Button variant="outline" onClick={handleLogout} className="border-red-300 text-red-600 hover:bg-red-50">
                  <LogOut className="w-4 h-4 mr-2" />
                  Logout
                </Button>
              </div>
            </nav>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2 rounded-lg hover:bg-gray-100"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Mobile Navigation */}
          {mobileMenuOpen && (
            <nav className="md:hidden mt-4 pt-4 border-t border-gray-200">
              <div className="flex flex-col space-y-3">
                <Link href="/home" className="text-gray-700 hover:text-orange-600 transition-colors">Home</Link>
                <Link href="/live-like-local" className="text-gray-700 hover:text-orange-600 transition-colors">Live Like Local</Link>
                <Link href="/community" className="text-gray-700 hover:text-orange-600 transition-colors">Community</Link>
                <Link href="/ai-assistant" className="text-gray-700 hover:text-orange-600 transition-colors">AI Assistant</Link>
                <div className="flex flex-col space-y-2 pt-2">
                  <Button variant="outline" className="border-orange-300 text-orange-600 hover:bg-orange-50 w-full">
                    <Shield className="w-4 h-4 mr-2" />
                    {user?.name || 'Dashboard'}
                  </Button>
                  <Button variant="outline" onClick={handleLogout} className="border-red-300 text-red-600 hover:bg-red-50 w-full">
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                  </Button>
                </div>
              </div>
            </nav>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-orange-400 via-orange-500 to-green-600 text-white">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative container mx-auto px-4 py-20 text-center">
          <h2 className="text-5xl md:text-6xl font-bold mb-6 animate-fade-in">
            Explore Incredible India
          </h2>
          <p className="text-xl md:text-2xl mb-8 text-orange-50">
            Discover the land of diversity, culture, and ancient wisdom
          </p>
          <div className="max-w-2xl mx-auto">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <Input
                type="text"
                placeholder="Search states, destinations, experiences..."
                className="pl-12 pr-4 py-4 text-lg rounded-full border-0 shadow-lg focus:ring-4 focus:ring-orange-300"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </div>
        
        {/* Decorative Elements */}
        <div className="absolute top-10 left-10 w-20 h-20 bg-yellow-400 rounded-full opacity-20 animate-pulse"></div>
        <div className="absolute bottom-10 right-10 w-32 h-32 bg-green-400 rounded-full opacity-20 animate-pulse"></div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card className="border-orange-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-6 text-center">
                <MapPin className="w-12 h-12 text-orange-500 mx-auto mb-4" />
                <h3 className="font-semibold text-gray-800">28 States</h3>
                <p className="text-sm text-gray-600">Explore diverse cultures</p>
              </CardContent>
            </Card>
            <Card className="border-green-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-6 text-center">
                <Users className="w-12 h-12 text-green-500 mx-auto mb-4" />
                <h3 className="font-semibold text-gray-800">Local Guides</h3>
                <p className="text-sm text-gray-600">Connect with locals</p>
              </CardContent>
            </Card>
            <Card className="border-blue-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-6 text-center">
                <Brain className="w-12 h-12 text-blue-500 mx-auto mb-4" />
                <h3 className="font-semibold text-gray-800">AI Assistant</h3>
                <p className="text-sm text-gray-600">Smart travel planning</p>
              </CardContent>
            </Card>
            <Card className="border-purple-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-6 text-center">
                <MessageCircle className="w-12 h-12 text-purple-500 mx-auto mb-4" />
                <h3 className="font-semibold text-gray-800">Community</h3>
                <p className="text-sm text-gray-600">Share experiences</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* States Grid Section */}
      <section className="py-16 bg-gradient-to-br from-orange-50 to-green-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Explore Indian States</h2>
            <p className="text-xl text-gray-600">Click on any state to discover its treasures</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredStates.map((state) => (
              <Link key={state.id} href={`/state/${state.slug}`}>
              <Card className="group hover:shadow-xl transition-all duration-300 cursor-pointer border-0 overflow-hidden">
                <div className="h-48 relative overflow-hidden">
                  <img 
                    src={state.image} 
                    alt={state.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent"></div>
                  <div className="absolute bottom-4 left-4 text-white">
                    <h3 className="text-2xl font-bold">{state.name}</h3>
                  </div>
                  <div className="absolute top-4 right-4">
                    <Badge className="bg-white/90 text-gray-800 hover:bg-white">
                      <Star className="w-3 h-3 mr-1" />
                      4.8
                    </Badge>
                  </div>
                </div>
                <CardContent className="p-4">
                  <p className="text-gray-600 mb-4 line-clamp-2">{state.description}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center text-sm text-gray-500">
                      <MapPin className="w-4 h-4 mr-1" />
                      <span>India</span>
                    </div>
                    <Button size="sm" className="bg-gradient-to-r from-orange-500 to-green-600 hover:from-orange-600 hover:to-green-700">
                      Explore
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Quick Actions Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">Quick Actions</h2>
            <p className="text-xl text-gray-600">Everything you need for your Indian journey</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="group hover:shadow-lg transition-all cursor-pointer border-orange-200">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-orange-200 transition-colors">
                  <Users className="w-8 h-8 text-orange-600" />
                </div>
                <h3 className="font-semibold text-gray-800 mb-2">Live Like Local</h3>
                <p className="text-sm text-gray-600 mb-4">Discover hidden gems shared by locals</p>
                <Link href="/live-like-local">
                  <Button variant="outline" className="border-orange-300 text-orange-600 hover:bg-orange-50">
                    Explore
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-lg transition-all cursor-pointer border-green-200">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-green-200 transition-colors">
                  <MessageCircle className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="font-semibold text-gray-800 mb-2">Solo Community</h3>
                <p className="text-sm text-gray-600 mb-4">Connect with fellow travelers</p>
                <Link href="/community">
                  <Button variant="outline" className="border-green-300 text-green-600 hover:bg-green-50">
                    Join Chat
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-lg transition-all cursor-pointer border-blue-200">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-200 transition-colors">
                  <Brain className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="font-semibold text-gray-800 mb-2">AI Assistant</h3>
                <p className="text-sm text-gray-600 mb-4">Get personalized travel advice</p>
                <Link href="/ai-assistant">
                  <Button variant="outline" className="border-blue-300 text-blue-600 hover:bg-blue-50">
                    Start Chat
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="group hover:shadow-lg transition-all cursor-pointer border-purple-200">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-purple-200 transition-colors">
                  <CreditCard className="w-8 h-8 text-purple-600" />
                </div>
                <h3 className="font-semibold text-gray-800 mb-2">Bookings</h3>
                <p className="text-sm text-gray-600 mb-4">Hotels, guides & experiences</p>
                <Link href="/bookings">
                  <Button variant="outline" className="border-purple-300 text-purple-600 hover:bg-purple-50">
                    Book Now
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-orange-600 to-green-700 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">Tourism India</h3>
              <p className="text-orange-100">Your gateway to exploring the incredible diversity of India.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-orange-100">
                <li><Link href="#" className="hover:text-white transition-colors">About Us</Link></li>
                <li><Link href="#" className="hover:text-white transition-colors">Contact</Link></li>
                <li><Link href="#" className="hover:text-white transition-colors">Privacy Policy</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Popular States</h4>
              <ul className="space-y-2 text-orange-100">
                <li><Link href="#" className="hover:text-white transition-colors">Rajasthan</Link></li>
                <li><Link href="#" className="hover:text-white transition-colors">Kerala</Link></li>
                <li><Link href="#" className="hover:text-white transition-colors">Goa</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Connect</h4>
              <p className="text-orange-100 mb-4">Follow us for travel inspiration</p>
              <div className="flex space-x-4">
                <Button variant="outline" size="sm" className="border-white/30 text-white hover:bg-white/20">
                  Facebook
                </Button>
                <Button variant="outline" size="sm" className="border-white/30 text-white hover:bg-white/20">
                  Instagram
                </Button>
              </div>
            </div>
          </div>
          <div className="border-t border-white/20 mt-8 pt-8 text-center text-orange-100">
            <p>© 2024 Tourism India. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}