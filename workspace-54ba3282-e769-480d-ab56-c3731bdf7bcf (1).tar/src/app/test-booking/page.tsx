'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { ArrowLeft, CheckCircle, AlertCircle, AlertTriangle } from 'lucide-react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'

export default function TestBookingPage() {
  const router = useRouter()
  const [testResult, setTestResult] = useState<string>('')
  const [isBooking, setIsBooking] = useState(false)

  const testBookingFlow = async () => {
    setIsBooking(true)
    setTestResult('Testing booking flow...')
    
    try {
      // Test 1: Check if API endpoint exists
      console.log('Testing booking API endpoint...')
      const testResponse = await fetch('/api/bookings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          itemName: 'Test Hotel Booking',
          itemType: 'hotel',
          price: 2500,
          location: 'Test Location',
          stateName: 'Test State',
          date: '2024-12-25',
          guests: '2',
          duration: '1 night',
          specialRequests: 'Test request',
          userEmail: 'test@example.com',
          userName: 'Test User'
        }),
      })

      const data = await testResponse.json()
      console.log('API Response:', data)
      
      if (testResponse.ok) {
        setTestResult(`✅ API Success! Transaction ID: ${data.transactionId}`)
        setIsBooking(false)
      } else {
        setTestResult(`❌ API Failed: ${data.error}`)
        setIsBooking(false)
      }
    } catch (error) {
      console.error('Booking error:', error)
      setTestResult(`❌ Network Error: ${error.message}`)
      setIsBooking(false)
    }
  }

  const testNotifications = () => {
    toast.success('🎉 Test Notification', {
      description: 'This is a test notification',
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-green-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-center">Booking Test</CardTitle>
          <CardDescription className="text-center">
            Test the booking confirmation flow
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center">
            <p className="text-sm text-gray-600 mb-4">
              Testing booking flow...
            </p>
            <Button onClick={testBookingFlow} disabled={isBooking} className="w-full">
              {isBooking ? (
                <div className="flex items-center">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  <span>Processing...</span>
                </div>
              ) : (
                <div className="flex items-center">
                  <CheckCircle className="w-5 h-5 text-green-500" />
                  <span>Test Booking API</span>
                </div>
              )}
            </div>
          
          {testResult && (
            <Alert className={testResult.includes('✅') ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}>
              <AlertDescription className={testResult.includes('✅') ? 'text-green-700' : 'text-red-700'}>
                {testResult}
              </AlertDescription>
            </Alert>
          )}
          
          <div className="text-center mt-6">
            <Link href="/home">
              <Button variant="outline">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}