import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/test-booking/route.ts - Get all bookings
export async function GET(request: NextRequest) {
  try {
    const bookings = await db.booking.findMany({
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true
          }
        },
        payment: true
      },
      orderBy: {
        createdAt: 'desc'
      }
    })

    return NextResponse.json(bookings)
  } catch (error) {
    console.error('Error fetching bookings:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    }
}

// POST /api/test-booking/route.ts - Create new booking
export async function POST(request: NextRequest) {
  try {
    const { itemName, itemType, price, location, stateName, date, guests, duration, specialRequests, userEmail, userName } = await request.json()

    if (!itemName || !price || !userEmail || !userName) {
      return NextResponse.json(
        { error: 'Missing required booking information' },
        { status: 400 }
      )
    }

    // Calculate total price
    const totalPrice = price * parseInt(guests)

    // Create booking record
    const booking = await db.booking.create({
      data: {
        itemType,
        itemName,
        price: totalPrice,
        status: 'confirmed',
        userId: 'user-1', // In a real app, this would come from authentication
      }
    })

    // Create payment record
    const payment = await db.payment.create({
      data: {
        userId: 'user-1', // In a real app, this would come from authentication
        amount: totalPrice,
        transactionId: `TOUR${Date.now()}`,
        status: 'completed',
        bookingId: booking.id
      }
    })

    // Send booking confirmation email
    try {
      await sendEmail(userEmail, 'bookingConfirmation', {
        userName,
        userEmail,
        itemName,
        itemType,
        location,
        stateName,
        date,
        guests,
        duration,
        specialRequests,
        totalPrice
      })
      console.log(`Booking confirmation email sent to ${userEmail}`)
    } catch (emailError) {
      console.error('Failed to send booking confirmation email:', emailError)
    }

    return NextResponse.json({
      message: 'Booking confirmed successfully',
      booking,
      payment,
      transactionId: payment.transactionId
    })

  } catch (error) {
    console.error('Booking error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}