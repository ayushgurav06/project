'use client'

import { useState, useEffect, useRef } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import { ArrowLeft, Users, MessageCircle, Plus, Search, Filter, Send, User, Calendar, MapPin, Heart, Share2 } from 'lucide-react'
import Link from 'next/link'
import { io, Socket } from 'socket.io-client'
import { toast } from 'sonner'

interface CommunityPost {
  id: string
  title: string
  content: string
  destination?: string
  travelInterest?: string
  createdAt: string
  author: {
    name: string
    email: string
  }
}

interface ChatMessage {
  id: string
  content: string
  sender: string
  timestamp: Date
}

const travelInterests = [
  'Adventure Sports', 'Cultural Tourism', 'Wildlife Safari', 'Beach Vacation',
  'Mountain Trekking', 'Spiritual Journey', 'Food Tourism', 'Photography',
  'Historical Sites', 'Backpacking', 'Luxury Travel', 'Eco Tourism'
]

export default function CommunityPage() {
  const [posts, setPosts] = useState<CommunityPost[]>([
    {
      id: '1',
      title: 'Solo Female Travel in Rajasthan',
      content: 'Just completed an amazing 10-day solo trip through Rajasthan! Visited Jaipur, Udaipur, and Jodhpur. Felt completely safe and the locals were incredibly helpful. Stayed in heritage hotels and even took a cooking class. Would highly recommend to other solo female travelers!',
      destination: 'Rajasthan',
      travelInterest: 'Cultural Tourism',
      createdAt: new Date().toISOString(),
      author: {
        name: 'Sarah Johnson',
        email: 'sarah@example.com'
      }
    },
    {
      id: '2',
      title: 'Himalayan Trekking Adventure',
      content: 'Completed the Hampta Pass trek last month. It was challenging but absolutely breathtaking! The views were worth every step. Met amazing fellow trekkers from around the world. If you\'re looking for an adventure, this is it!',
      destination: 'Himachal Pradesh',
      travelInterest: 'Mountain Trekking',
      createdAt: new Date().toISOString(),
      author: {
        name: 'Mike Chen',
        email: 'mike@example.com'
      }
    }
  ])
  const [filteredPosts, setFilteredPosts] = useState<CommunityPost[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedInterest, setSelectedInterest] = useState('all')
  const [isLoading, setIsLoading] = useState(false)
  const [showCreateDialog, setShowCreateDialog] = useState(false)
  const [newPost, setNewPost] = useState({
    title: '',
    content: '',
    destination: '',
    travelInterest: ''
  })
  
  // Chat state
  const [showChat, setShowChat] = useState(false)
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([])
  const [newMessage, setNewMessage] = useState('')
  const [username, setUsername] = useState(`Traveler_${Math.floor(Math.random() * 1000)}`)
  const [socket, setSocket] = useState<Socket | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    fetchPosts()
    
    // Initialize socket connection
    const newSocket = io('http://localhost:3000', {
      path: '/api/socketio'
    })
    
    newSocket.on('connect', () => {
      console.log('Connected to chat server')
    })
    
    newSocket.on('chat-message', (message: ChatMessage) => {
      setChatMessages(prev => [...prev, message])
    })
    
    setSocket(newSocket)
    
    return () => {
      newSocket.close()
    }
  }, [])

  useEffect(() => {
    filterPosts()
  }, [posts, searchTerm, selectedInterest])

  useEffect(() => {
    scrollToBottom()
  }, [chatMessages])

  const fetchPosts = async () => {
    try {
      const response = await fetch('/api/community-posts')
      if (response.ok) {
        const data = await response.json()
        setPosts(data)
      }
    } catch (error) {
      console.error('Error fetching posts:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const filterPosts = () => {
    let filtered = posts

    if (searchTerm) {
      filtered = filtered.filter(post =>
        post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        post.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (post.destination && post.destination.toLowerCase().includes(searchTerm.toLowerCase()))
      )
    }

    if (selectedInterest !== 'all') {
      filtered = filtered.filter(post => post.travelInterest === selectedInterest)
    }

    setFilteredPosts(filtered)
  }

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault()
    
    try {
      const response = await fetch('/api/community-posts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...newPost,
          authorId: 'user-1' // In a real app, this would come from authentication
        }),
      })

      if (response.ok) {
        toast.success('📝 Post Published!', {
          description: `Your post "${newPost.title}" has been shared with the community!`,
          duration: 5000,
        })
        
        setShowCreateDialog(false)
        setNewPost({ title: '', content: '', destination: '', travelInterest: '' })
        fetchPosts()
      } else {
        toast.error('Failed to publish post', {
          description: 'Please try again later.',
          duration: 4000,
        })
      }
    } catch (error) {
      toast.error('Network error', {
        description: 'Please check your connection and try again.',
        duration: 4000,
      })
    }
  }

  const handleSendMessage = () => {
    if (!newMessage.trim() || !socket) return

    const message: ChatMessage = {
      id: Date.now().toString(),
      content: newMessage,
      sender: username,
      timestamp: new Date()
    }

    socket.emit('chat-message', message)
    setNewMessage('')
  }

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-purple-200 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/" className="inline-flex items-center text-purple-600 hover:text-purple-700">
                <ArrowLeft className="w-5 h-5 mr-2" />
                Back
              </Link>
              <div className="flex items-center space-x-2">
                <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-600 rounded-full flex items-center justify-center">
                  <Users className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-800">Solo Traveller Community</h1>
                  <p className="text-sm text-gray-600">Connect with fellow travelers</p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
                <DialogTrigger asChild>
                  <Button className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Create Post
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[500px]">
                  <DialogHeader>
                    <DialogTitle>Share Your Travel Experience</DialogTitle>
                    <DialogDescription>
                      Connect with solo travelers and share your journey
                    </DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleCreatePost} className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">Title</label>
                      <Input
                        value={newPost.title}
                        onChange={(e) => setNewPost({ ...newPost, title: e.target.value })}
                        placeholder="Give your post a catchy title"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Your Story</label>
                      <Textarea
                        value={newPost.content}
                        onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
                        placeholder="Share your travel experience, tips, or questions"
                        rows={4}
                        required
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Destination (optional)</label>
                      <Input
                        value={newPost.destination}
                        onChange={(e) => setNewPost({ ...newPost, destination: e.target.value })}
                        placeholder="Where did you travel?"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Travel Interest</label>
                      <Select value={newPost.travelInterest} onValueChange={(value) => setNewPost({ ...newPost, travelInterest: value })}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select your travel interest" />
                        </SelectTrigger>
                        <SelectContent>
                          {travelInterests.map((interest) => (
                            <SelectItem key={interest} value={interest}>{interest}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex justify-end space-x-2">
                      <Button type="button" variant="outline" onClick={() => setShowCreateDialog(false)}>
                        Cancel
                      </Button>
                      <Button type="submit" className="bg-gradient-to-r from-purple-500 to-pink-600">
                        Share Post
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
              
              <Button 
                onClick={() => setShowChat(!showChat)}
                variant="outline" 
                className="border-purple-300 text-purple-600 hover:bg-purple-50"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                Live Chat
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        {/* Search and Filter */}
        <Card className="mb-6 border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search posts, destinations, experiences..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Filter className="w-4 h-4 text-gray-500" />
                <Select value={selectedInterest} onValueChange={setSelectedInterest}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Filter by interest" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Interests</SelectItem>
                    {travelInterests.map((interest) => (
                      <SelectItem key={interest} value={interest}>{interest}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Posts Grid */}
        {isLoading ? (
          <div className="text-center py-12">
            <div className="inline-flex items-center space-x-2">
              <div className="w-6 h-6 border-2 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
              <span className="text-gray-600">Loading community posts...</span>
            </div>
          </div>
        ) : filteredPosts.length === 0 ? (
          <div className="text-center py-12">
            <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-600 mb-2">No posts found</h3>
            <p className="text-gray-500 mb-6">
              {searchTerm || selectedInterest !== 'all' 
                ? 'Try adjusting your search or filters' 
                : 'Be the first to share your travel story!'}
            </p>
            <Button 
              onClick={() => setShowCreateDialog(true)}
              className="bg-gradient-to-r from-purple-500 to-pink-600"
            >
              <Plus className="w-4 h-4 mr-2" />
              Share First Post
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPosts.map((post) => (
              <Card key={post.id} className="group hover:shadow-lg transition-all duration-300 border-0 overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <h3 className="font-semibold text-gray-800 group-hover:text-purple-600 transition-colors line-clamp-2">
                      {post.title}
                    </h3>
                  </div>
                  <p className="text-gray-600 text-sm mb-4 line-clamp-3">
                    {post.content}
                  </p>
                  
                  {post.destination && (
                    <div className="flex items-center text-sm text-gray-500 mb-2">
                      <MapPin className="w-3 h-3 mr-1" />
                      <span>{post.destination}</span>
                    </div>
                  )}
                  
                  {post.travelInterest && (
                    <Badge variant="outline" className="mb-3 text-xs">
                      {post.travelInterest}
                    </Badge>
                  )}
                  
                  <div className="flex items-center justify-between text-sm text-gray-500 mb-3">
                    <div className="flex items-center">
                      <User className="w-3 h-3 mr-1" />
                      <span>{post.author.name}</span>
                    </div>
                    <div className="flex items-center">
                      <Calendar className="w-3 h-3 mr-1" />
                      <span>{new Date(post.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <button className="flex items-center space-x-1 text-gray-500 hover:text-red-500 transition-colors">
                        <Heart className="w-4 h-4" />
                        <span className="text-sm">Like</span>
                      </button>
                      <button className="flex items-center space-x-1 text-gray-500 hover:text-blue-500 transition-colors">
                        <MessageCircle className="w-4 h-4" />
                        <span className="text-sm">Comment</span>
                      </button>
                      <button className="flex items-center space-x-1 text-gray-500 hover:text-green-500 transition-colors">
                        <Share2 className="w-4 h-4" />
                        <span className="text-sm">Share</span>
                      </button>
                    </div>
                    <Button size="sm" variant="outline" className="text-xs">
                      Read More
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Live Chat Sidebar */}
      {showChat && (
        <div className="fixed bottom-4 right-4 w-80 h-96 bg-white rounded-lg shadow-2xl border border-purple-200 flex flex-col z-50">
          <div className="bg-gradient-to-r from-purple-500 to-pink-600 text-white p-3 rounded-t-lg flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <MessageCircle className="w-4 h-4" />
              <span className="font-semibold">Live Chat</span>
            </div>
            <button
              onClick={() => setShowChat(false)}
              className="text-white hover:bg-white/20 rounded p-1"
            >
              ×
            </button>
          </div>
          
          <ScrollArea className="flex-1 p-3">
            <div className="space-y-2">
              {chatMessages.map((message) => (
                <div
                  key={message.id}
                  className={`p-2 rounded-lg max-w-[80%] ${
                    message.sender === username
                      ? 'bg-purple-100 ml-auto'
                      : 'bg-gray-100'
                  }`}
                >
                  <div className="text-xs font-semibold text-gray-600 mb-1">
                    {message.sender}
                  </div>
                  <div className="text-sm">{message.content}</div>
                  <div className="text-xs text-gray-500 mt-1">
                    {message.timestamp.toLocaleTimeString()}
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>
          
          <div className="p-3 border-t">
            <div className="flex space-x-2">
              <Input
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder="Type a message..."
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                className="flex-1"
              />
              <Button onClick={handleSendMessage} size="sm" className="bg-purple-500 hover:bg-purple-600">
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}