'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { ArrowLeft, MapPin, Heart, MessageCircle, Plus, Search, Filter, Camera, User, Calendar } from 'lucide-react'
import Link from 'next/link'
import { toast } from 'sonner'

interface LocalPost {
  id: string
  title: string
  description: string
  image?: string
  location: string
  likes: number
  createdAt: string
  author: {
    name: string
    email: string
  }
  state: {
    name: string
  }
}

const indianStates = [
  'Rajasthan', 'Kerala', 'Goa', 'Uttar Pradesh', 'Maharashtra', 'Tamil Nadu',
  'Himachal Pradesh', 'West Bengal', 'Gujarat', 'Madhya Pradesh', 'Karnataka', 'Delhi'
]

export default function LiveLikeLocalPage() {
  const [posts, setPosts] = useState<LocalPost[]>([
    {
      id: '1',
      title: 'Hidden Village in Udaipur',
      description: 'Discover the untouched beauty of a small Rajasthani village where time stands still. Traditional mud houses, local artisans, and authentic Rajasthani cuisine await.',
      image: '/features/local-gem.jpg',
      location: 'Udaipur',
      likes: 24,
      createdAt: new Date().toISOString(),
      author: {
        name: 'Rajesh Kumar',
        email: 'rajesh@example.com'
      },
      state: {
        name: 'Rajasthan'
      }
    },
    {
      id: '2',
      title: 'Secret Beach in Kerala',
      description: 'A pristine beach near Kovalam that only locals know about. Perfect for watching sunsets and enjoying fresh coconut water.',
      location: 'Kovalam',
      likes: 18,
      createdAt: new Date().toISOString(),
      author: {
        name: 'Priya Nair',
        email: 'priya@example.com'
      },
      state: {
        name: 'Kerala'
      }
    }
  ])
  const [filteredPosts, setFilteredPosts] = useState<LocalPost[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedState, setSelectedState] = useState('all')
  const [isLoading, setIsLoading] = useState(false)
  const [showCreateDialog, setShowCreateDialog] = useState(false)
  const [newPost, setNewPost] = useState({
    title: '',
    description: '',
    location: '',
    stateId: '',
    image: ''
  })

  useEffect(() => {
    fetchPosts()
  }, [])

  useEffect(() => {
    filterPosts()
  }, [posts, searchTerm, selectedState])

  const fetchPosts = async () => {
    try {
      const response = await fetch('/api/local-posts')
      if (response.ok) {
        const data = await response.json()
        setPosts(data)
      }
    } catch (error) {
      console.error('Error fetching posts:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const filterPosts = () => {
    let filtered = posts

    if (searchTerm) {
      filtered = filtered.filter(post =>
        post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        post.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        post.location.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    if (selectedState !== 'all') {
      filtered = filtered.filter(post => post.state.name === selectedState)
    }

    setFilteredPosts(filtered)
  }

  const handleCreatePost = async (e: React.FormEvent) => {
    e.preventDefault()
    
    try {
      const response = await fetch('/api/local-posts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...newPost,
          authorId: 'user-1' // In a real app, this would come from authentication
        }),
      })

      if (response.ok) {
        toast.success('🌟 Hidden Gem Shared!', {
          description: `Your post "${newPost.title}" has been shared successfully!`,
          duration: 5000,
        })
        
        setShowCreateDialog(false)
        setNewPost({ title: '', description: '', location: '', stateId: '', image: '' })
        fetchPosts()
      } else {
        toast.error('Failed to share post', {
          description: 'Please try again later.',
          duration: 4000,
        })
      }
    } catch (error) {
      toast.error('Network error', {
        description: 'Please check your connection and try again.',
        duration: 4000,
      })
    }
  }

  const handleLike = async (postId: string) => {
    // In a real app, this would call an API to like the post
    setPosts(posts.map(post => 
      post.id === postId ? { ...post, likes: post.likes + 1 } : post
    ))
    
    // Show a subtle like notification
    toast.success('❤️ Liked!', {
      description: 'You liked this hidden gem',
      duration: 2000,
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-green-50">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-orange-200 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/" className="inline-flex items-center text-orange-600 hover:text-orange-700">
                <ArrowLeft className="w-5 h-5 mr-2" />
                Back
              </Link>
              <div className="flex items-center space-x-2">
                <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-teal-600 rounded-full flex items-center justify-center">
                  <MapPin className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-800">Live Like a Local</h1>
                  <p className="text-sm text-gray-600">Discover hidden gems shared by locals</p>
                </div>
              </div>
            </div>
            
            <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
              <DialogTrigger asChild>
                <Button className="bg-gradient-to-r from-green-500 to-teal-600 hover:from-green-600 hover:to-teal-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Share Hidden Gem
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>Share Your Local Secret</DialogTitle>
                  <DialogDescription>
                    Help others discover amazing places only locals know about
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleCreatePost} className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Title</label>
                    <Input
                      value={newPost.title}
                      onChange={(e) => setNewPost({ ...newPost, title: e.target.value })}
                      placeholder="Give your discovery a catchy title"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Description</label>
                    <Textarea
                      value={newPost.description}
                      onChange={(e) => setNewPost({ ...newPost, description: e.target.value })}
                      placeholder="Describe this hidden gem and why it's special"
                      rows={3}
                      required
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Location</label>
                    <Input
                      value={newPost.location}
                      onChange={(e) => setNewPost({ ...newPost, location: e.target.value })}
                      placeholder="Specific location or area"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">State</label>
                    <Select value={newPost.stateId} onValueChange={(value) => setNewPost({ ...newPost, stateId: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select state" />
                      </SelectTrigger>
                      <SelectContent>
                        {indianStates.map((state) => (
                          <SelectItem key={state} value={state}>{state}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Image URL (optional)</label>
                    <Input
                      value={newPost.image}
                      onChange={(e) => setNewPost({ ...newPost, image: e.target.value })}
                      placeholder="https://example.com/image.jpg"
                    />
                  </div>
                  <div className="flex justify-end space-x-2">
                    <Button type="button" variant="outline" onClick={() => setShowCreateDialog(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" className="bg-gradient-to-r from-green-500 to-teal-600">
                      Share Hidden Gem
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        {/* Search and Filter */}
        <Card className="mb-6 border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search hidden gems, locations, descriptions..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Filter className="w-4 h-4 text-gray-500" />
                <Select value={selectedState} onValueChange={setSelectedState}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Filter by state" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All States</SelectItem>
                    {indianStates.map((state) => (
                      <SelectItem key={state} value={state}>{state}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Posts Grid */}
        {isLoading ? (
          <div className="text-center py-12">
            <div className="inline-flex items-center space-x-2">
              <div className="w-6 h-6 border-2 border-orange-500 border-t-transparent rounded-full animate-spin"></div>
              <span className="text-gray-600">Loading hidden gems...</span>
            </div>
          </div>
        ) : filteredPosts.length === 0 ? (
          <div className="text-center py-12">
            <MapPin className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-600 mb-2">No hidden gems found</h3>
            <p className="text-gray-500 mb-6">
              {searchTerm || selectedState !== 'all' 
                ? 'Try adjusting your search or filters' 
                : 'Be the first to share a hidden gem!'}
            </p>
            <Button 
              onClick={() => setShowCreateDialog(true)}
              className="bg-gradient-to-r from-green-500 to-teal-600"
            >
              <Plus className="w-4 h-4 mr-2" />
              Share First Hidden Gem
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPosts.map((post) => (
              <Card key={post.id} className="group hover:shadow-lg transition-all duration-300 border-0 overflow-hidden">
                {post.image && (
                  <div className="h-48 bg-gradient-to-br from-green-100 to-teal-100 relative overflow-hidden">
                    <img 
                      src={post.image} 
                      alt={post.title}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        e.currentTarget.src = '/api/placeholder?width=400&height=300'
                      }}
                    />
                    <div className="absolute top-3 right-3">
                      <Badge className="bg-white/90 text-gray-800">
                        {post.state.name}
                      </Badge>
                    </div>
                  </div>
                )}
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-semibold text-gray-800 group-hover:text-orange-600 transition-colors">
                      {post.title}
                    </h3>
                    <Badge variant="outline" className="text-xs">
                      <MapPin className="w-3 h-3 mr-1" />
                      {post.location}
                    </Badge>
                  </div>
                  <p className="text-gray-600 text-sm mb-4 line-clamp-3">
                    {post.description}
                  </p>
                  <div className="flex items-center justify-between text-sm text-gray-500 mb-3">
                    <div className="flex items-center">
                      <User className="w-3 h-3 mr-1" />
                      <span>{post.author.name}</span>
                    </div>
                    <div className="flex items-center">
                      <Calendar className="w-3 h-3 mr-1" />
                      <span>{new Date(post.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <button
                        onClick={() => handleLike(post.id)}
                        className="flex items-center space-x-1 text-gray-500 hover:text-red-500 transition-colors"
                      >
                        <Heart className="w-4 h-4" />
                        <span className="text-sm">{post.likes}</span>
                      </button>
                      <button className="flex items-center space-x-1 text-gray-500 hover:text-blue-500 transition-colors">
                        <MessageCircle className="w-4 h-4" />
                        <span className="text-sm">Comment</span>
                      </button>
                    </div>
                    <Button size="sm" variant="outline" className="text-xs">
                      View Details
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}