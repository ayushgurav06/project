'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { ArrowLeft, Users, MapPin, Calendar, CreditCard, Mail, Settings, Database, Plus, Edit, Trash2, Eye, BarChart3, Shield, LogOut, Search, Filter } from 'lucide-react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'

interface User {
  id: string
  email: string
  name: string
  role: string
  createdAt: string
}

interface State {
  id: string
  name: string
  description: string
  image: string
  capital: string
  bestTimeToVisit: string
  culturalEvents: string
  createdAt: string
}

interface Booking {
  id: string
  itemType: string
  itemName: string
  price: number
  status: string
  createdAt: string
  user: {
    name: string
    email: string
  }
}

interface LocalPost {
  id: string
  title: string
  description: string
  location: string
  likes: number
  createdAt: string
  author: {
    name: string
    email: string
  }
  state: {
    name: string
  }
}

export default function AdminDashboard() {
  const router = useRouter()
  const [isAdmin, setIsAdmin] = useState(false)
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('overview')
  
  // Data states
  const [users, setUsers] = useState<User[]>([])
  const [states, setStates] = useState<State[]>([])
  const [bookings, setBookings] = useState<Booking[]>([])
  const [localPosts, setLocalPosts] = useState<LocalPost[]>([])
  
  // Form states
  const [showUserDialog, setShowUserDialog] = useState(false)
  const [showStateDialog, setShowStateDialog] = useState(false)
  const [editingUser, setEditingUser] = useState<User | null>(null)
  const [editingState, setEditingState] = useState<State | null>(null)
  
  // Form data
  const [userForm, setUserForm] = useState({ name: '', email: '', role: 'user' })
  const [stateForm, setStateForm] = useState({
    name: '',
    description: '',
    image: '',
    capital: '',
    bestTimeToVisit: '',
    culturalEvents: ''
  })

  useEffect(() => {
    checkAdminAuth()
  }, [])

  const checkAdminAuth = () => {
    const userData = localStorage.getItem('user') || sessionStorage.getItem('user')
    if (userData) {
      const user = JSON.parse(userData)
      if (user.email === 'ayushgurav0608@gmail.com' && user.role === 'admin') {
        setIsAdmin(true)
        fetchData()
      } else {
        router.push('/')
      }
    } else {
      router.push('/')
    }
    setLoading(false)
  }

  const fetchData = async () => {
    try {
      // Fetch users
      const usersResponse = await fetch('/api/admin/users')
      if (usersResponse.ok) {
        const usersData = await usersResponse.json()
        setUsers(usersData)
      }

      // Fetch states
      const statesResponse = await fetch('/api/states')
      if (statesResponse.ok) {
        const statesData = await statesResponse.json()
        setStates(statesData)
      }

      // Fetch bookings
      const bookingsResponse = await fetch('/api/admin/bookings')
      if (bookingsResponse.ok) {
        const bookingsData = await bookingsResponse.json()
        setBookings(bookingsData)
      }

      // Fetch local posts
      const postsResponse = await fetch('/api/admin/local-posts')
      if (postsResponse.ok) {
        const postsData = await postsResponse.json()
        setLocalPosts(postsData)
      }
    } catch (error) {
      console.error('Error fetching data:', error)
      toast.error('Failed to fetch admin data')
    }
  }

  const handleLogout = () => {
    localStorage.removeItem('user')
    sessionStorage.removeItem('user')
    router.push('/')
  }

  const handleCreateUser = async () => {
    try {
      const response = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(userForm)
      })

      if (response.ok) {
        toast.success('User created successfully')
        setShowUserDialog(false)
        setUserForm({ name: '', email: '', role: 'user' })
        fetchData()
      } else {
        const error = await response.json()
        toast.error(error.error || 'Failed to create user')
      }
    } catch (error) {
      toast.error('Network error')
    }
  }

  const handleCreateState = async () => {
    try {
      const response = await fetch('/api/states', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(stateForm)
      })

      if (response.ok) {
        toast.success('State created successfully')
        setShowStateDialog(false)
        setStateForm({
          name: '',
          description: '',
          image: '',
          capital: '',
          bestTimeToVisit: '',
          culturalEvents: ''
        })
        fetchData()
      } else {
        const error = await response.json()
        toast.error(error.error || 'Failed to create state')
      }
    } catch (error) {
      toast.error('Network error')
    }
  }

  const handleDeleteUser = async (userId: string) => {
    if (confirm('Are you sure you want to delete this user?')) {
      try {
        const response = await fetch(`/api/admin/users/${userId}`, {
          method: 'DELETE'
        })

        if (response.ok) {
          toast.success('User deleted successfully')
          fetchData()
        } else {
          toast.error('Failed to delete user')
        }
      } catch (error) {
        toast.error('Network error')
      }
    }
  }

  const handleDeleteState = async (stateId: string) => {
    if (confirm('Are you sure you want to delete this state?')) {
      try {
        const response = await fetch(`/api/admin/states/${stateId}`, {
          method: 'DELETE'
        })

        if (response.ok) {
          toast.success('State deleted successfully')
          fetchData()
        } else {
          toast.error('Failed to delete state')
        }
      } catch (error) {
        toast.error('Network error')
      }
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading admin dashboard...</p>
        </div>
      </div>
    )
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Shield className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Access Denied</h2>
          <p className="text-gray-600 mb-4">You don't have permission to access this page</p>
          <Button onClick={() => router.push('/')}>Go Home</Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/home" className="inline-flex items-center text-gray-600 hover:text-gray-900">
                <ArrowLeft className="w-5 h-5 mr-2" />
                Back to Home
              </Link>
              <div className="flex items-center space-x-2">
                <Shield className="w-8 h-8 text-orange-600" />
                <div>
                  <h1 className="text-xl font-bold text-gray-800">Admin Dashboard</h1>
                  <p className="text-sm text-gray-600">Database Management</p>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Badge className="bg-green-100 text-green-700">
                Admin: ayushgurav0608@gmail.com
              </Badge>
              <Button variant="outline" onClick={handleLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Users</p>
                  <p className="text-2xl font-bold text-gray-900">{users.length}</p>
                </div>
                <Users className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">States</p>
                  <p className="text-2xl font-bold text-gray-900">{states.length}</p>
                </div>
                <MapPin className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Bookings</p>
                  <p className="text-2xl font-bold text-gray-900">{bookings.length}</p>
                </div>
                <CreditCard className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Local Posts</p>
                  <p className="text-2xl font-bold text-gray-900">{localPosts.length}</p>
                </div>
                <Mail className="w-8 h-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="states">States</TabsTrigger>
            <TabsTrigger value="content">Content</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Users</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {users.slice(0, 5).map((user) => (
                      <div key={user.id} className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{user.name}</p>
                          <p className="text-sm text-gray-600">{user.email}</p>
                        </div>
                        <Badge variant={user.role === 'admin' ? 'default' : 'secondary'}>
                          {user.role}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Recent Bookings</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {bookings.slice(0, 5).map((booking) => (
                      <div key={booking.id} className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{booking.itemName}</p>
                          <p className="text-sm text-gray-600">{booking.user.name}</p>
                        </div>
                        <Badge variant={booking.status === 'confirmed' ? 'default' : 'secondary'}>
                          {booking.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-800">User Management</h2>
              <Dialog open={showUserDialog} onOpenChange={setShowUserDialog}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="w-4 h-4 mr-2" />
                    Add User
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Create New User</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="name">Name</Label>
                      <Input
                        id="name"
                        value={userForm.name}
                        onChange={(e) => setUserForm({ ...userForm, name: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={userForm.email}
                        onChange={(e) => setUserForm({ ...userForm, email: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="role">Role</Label>
                      <Select value={userForm.role} onValueChange={(value) => setUserForm({ ...userForm, role: value })}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="user">User</SelectItem>
                          <SelectItem value="admin">Admin</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <Button onClick={handleCreateUser} className="w-full">
                      Create User
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Created</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {users.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell className="font-medium">{user.name}</TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell>
                          <Badge variant={user.role === 'admin' ? 'default' : 'secondary'}>
                            {user.role}
                          </Badge>
                        </TableCell>
                        <TableCell>{new Date(user.createdAt).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm">
                              <Eye className="w-4 h-4" />
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => handleDeleteUser(user.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* States Tab */}
          <TabsContent value="states" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-800">State Management</h2>
              <Dialog open={showStateDialog} onOpenChange={setShowStateDialog}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="w-4 h-4 mr-2" />
                    Add State
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>Add New State</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="stateName">State Name</Label>
                        <Input
                          id="stateName"
                          value={stateForm.name}
                          onChange={(e) => setStateForm({ ...stateForm, name: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="capital">Capital</Label>
                        <Input
                          id="capital"
                          value={stateForm.capital}
                          onChange={(e) => setStateForm({ ...stateForm, capital: e.target.value })}
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        value={stateForm.description}
                        onChange={(e) => setStateForm({ ...stateForm, description: e.target.value })}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="image">Image URL</Label>
                        <Input
                          id="image"
                          value={stateForm.image}
                          onChange={(e) => setStateForm({ ...stateForm, image: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="bestTime">Best Time to Visit</Label>
                        <Input
                          id="bestTime"
                          value={stateForm.bestTimeToVisit}
                          onChange={(e) => setStateForm({ ...stateForm, bestTimeToVisit: e.target.value })}
                        />
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="events">Cultural Events (comma-separated)</Label>
                      <Input
                        id="events"
                        value={stateForm.culturalEvents}
                        onChange={(e) => setStateForm({ ...stateForm, culturalEvents: e.target.value })}
                        placeholder="Event 1, Event 2, Event 3"
                      />
                    </div>
                    <Button onClick={handleCreateState} className="w-full">
                      Add State
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {states.map((state) => (
                <Card key={state.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{state.name}</CardTitle>
                        <CardDescription>{state.capital}</CardDescription>
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleDeleteState(state.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-2">{state.description}</p>
                    <div className="text-xs text-gray-500">
                      <p>Best time: {state.bestTimeToVisit}</p>
                      <p>Created: {new Date(state.createdAt).toLocaleDateString()}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Content Tab */}
          <TabsContent value="content" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Local Posts</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {localPosts.slice(0, 5).map((post) => (
                      <div key={post.id} className="border-b pb-3">
                        <h4 className="font-medium">{post.title}</h4>
                        <p className="text-sm text-gray-600">{post.author.name} - {post.state.name}</p>
                        <div className="flex items-center justify-between mt-1">
                          <span className="text-xs text-gray-500">{post.likes} likes</span>
                          <span className="text-xs text-gray-500">{new Date(post.createdAt).toLocaleDateString()}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Database Statistics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Total Users</span>
                      <span className="text-sm font-bold">{users.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Total States</span>
                      <span className="text-sm font-bold">{states.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Total Bookings</span>
                      <span className="text-sm font-bold">{bookings.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Total Posts</span>
                      <span className="text-sm font-bold">{localPosts.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Admin Users</span>
                      <span className="text-sm font-bold">{users.filter(u => u.role === 'admin').length}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}