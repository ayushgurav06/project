'use client'

import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { ArrowLeft, Calendar, MapPin, Users, CreditCard, Search, Filter, Star, Clock, Check } from 'lucide-react'
import Link from 'next/link'
import { toast } from 'sonner'

interface BookingItem {
  id: string
  name: string
  type: 'hotel' | 'guide' | 'experience'
  price: number
  location: string
  rating: number
  duration?: string
  availability: boolean
  description: string
}

const bookingItems: BookingItem[] = [
  {
    id: '1',
    name: 'Taj Mahal Sunrise Tour',
    type: 'experience',
    price: 2999,
    location: 'Agra, Uttar Pradesh',
    rating: 4.8,
    duration: '6 hours',
    availability: true,
    description: 'Experience the breathtaking beauty of Taj Mahal at sunrise with expert guide'
  },
  {
    id: '2',
    name: 'Rajasthan Heritage Hotel',
    type: 'hotel',
    price: 4500,
    location: 'Jaipur, Rajasthan',
    rating: 4.6,
    availability: true,
    description: 'Luxury heritage hotel with traditional Rajasthani architecture and modern amenities'
  },
  {
    id: '3',
    name: 'Kerala Backwaters Houseboat',
    type: 'experience',
    price: 3500,
    location: 'Alleppey, Kerala',
    rating: 4.9,
    duration: '1 night',
    availability: true,
    description: 'Overnight stay in traditional houseboat through serene Kerala backwaters'
  },
  {
    id: '4',
    name: 'Local City Guide - Delhi',
    type: 'guide',
    price: 1500,
    location: 'Delhi',
    rating: 4.7,
    duration: '8 hours',
    availability: true,
    description: 'Expert local guide for exploring Delhi\'s hidden gems and historical sites'
  },
  {
    id: '5',
    name: 'Goa Beach Resort',
    type: 'hotel',
    price: 3200,
    location: 'North Goa, Goa',
    rating: 4.5,
    availability: false,
    description: 'Beachfront resort with stunning ocean views and water sports activities'
  },
  {
    id: '6',
    name: 'Himalayan Trekking Guide',
    type: 'guide',
    price: 2500,
    location: 'Manali, Himachal Pradesh',
    rating: 4.9,
    duration: '2 days',
    availability: true,
    description: 'Experienced trekking guide for Himalayan mountain adventures'
  }
]

export default function BookingsPage() {
  const [filteredItems, setFilteredItems] = useState(bookingItems)
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedType, setSelectedType] = useState('all')
  const [selectedLocation, setSelectedLocation] = useState('all')
  const [showBookingDialog, setShowBookingDialog] = useState(false)
  const [selectedItem, setSelectedItem] = useState<BookingItem | null>(null)
  const [bookingDetails, setBookingDetails] = useState({
    date: '',
    guests: '1',
    specialRequests: ''
  })

  const locations = Array.from(new Set(bookingItems.map(item => item.location.split(',')[1]?.trim() || '')))

  const filterItems = () => {
    let filtered = bookingItems

    if (searchTerm) {
      filtered = filtered.filter(item =>
        item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.location.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    if (selectedType !== 'all') {
      filtered = filtered.filter(item => item.type === selectedType)
    }

    if (selectedLocation !== 'all') {
      filtered = filtered.filter(item => item.location.includes(selectedLocation))
    }

    setFilteredItems(filtered)
  }

  useState(() => {
    filterItems()
  }, [searchTerm, selectedType, selectedLocation])

  const handleBooking = (item: BookingItem) => {
    setSelectedItem(item)
    setShowBookingDialog(true)
  }

  const confirmBooking = async () => {
    if (selectedItem) {
      const totalPrice = selectedItem.price * parseInt(bookingDetails.guests)
      const guestText = parseInt(bookingDetails.guests) === 1 ? '1 guest' : `${bookingDetails.guests} guests`
      
      try {
        // Call booking API
        const response = await fetch('/api/bookings', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            itemName: selectedItem.name,
            itemType: selectedItem.type,
            price: selectedItem.price,
            location: selectedItem.location,
            stateName: 'Various States',
            date: bookingDetails.date,
            guests: bookingDetails.guests,
            duration: selectedItem.duration,
            specialRequests: bookingDetails.specialRequests,
            userEmail: 'user@example.com', // In a real app, this would come from authentication
            userName: 'Demo User' // In a real app, this would come from authentication
          }),
        })

        const data = await response.json()

        if (response.ok) {
          // Show success notification
          toast.success('🎉 Booking Confirmed!', {
            description: `${selectedItem.name} for ${guestText} on ${bookingDetails.date}`,
            duration: 6000,
          })
          
          // Show detailed booking confirmation
          toast.success('📧 Booking Details Sent!', {
            description: `Transaction ID: ${data.transactionId} | Total: ₹${totalPrice} | Email: user@example.com`,
            duration: 8000,
          })
          
          // Show next steps notification
          toast.info('✅ Next Steps', {
            description: 'Check your email for complete booking details. Save this transaction ID for future reference.',
            duration: 6000,
          })
          
          // Show final confirmation message
          toast.success('🎊 Booking Successful!', {
            description: 'Your adventure in India is confirmed. We\'ll send you reminders and updates!',
            duration: 5000,
          })
          
          setShowBookingDialog(false)
          setBookingDetails({ date: '', guests: '1', specialRequests: '' })
        } else {
          toast.error('Booking failed', {
            description: data.error || 'Please try again.',
            duration: 4000,
          })
        }
      } catch (error) {
        toast.error('Network error', {
          description: 'Please check your connection and try again.',
          duration: 4000,
        })
      }
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'hotel':
        return '🏨'
      case 'guide':
        return '👤'
      case 'experience':
        return '🎯'
      default:
        return '📍'
    }
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'hotel':
        return 'bg-blue-100 text-blue-700'
      case 'guide':
        return 'bg-green-100 text-green-700'
      case 'experience':
        return 'bg-purple-100 text-purple-700'
      default:
        return 'bg-gray-100 text-gray-700'
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-indigo-200 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/" className="inline-flex items-center text-indigo-600 hover:text-indigo-700">
                <ArrowLeft className="w-5 h-5 mr-2" />
                Back
              </Link>
              <div className="flex items-center space-x-2">
                <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center">
                  <CreditCard className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-800">Bookings & Reservations</h1>
                  <p className="text-sm text-gray-600">Hotels, guides & experiences</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        {/* Search and Filter */}
        <Card className="mb-6 border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search hotels, guides, experiences..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Filter className="w-4 h-4 text-gray-500" />
                <Select value={selectedType} onValueChange={setSelectedType}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="hotel">Hotels</SelectItem>
                    <SelectItem value="guide">Guides</SelectItem>
                    <SelectItem value="experience">Experiences</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Location" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Locations</SelectItem>
                    {locations.map((location) => (
                      <SelectItem key={location} value={location}>{location}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results Count */}
        <div className="mb-4 flex items-center justify-between">
          <p className="text-gray-600">
            Showing {filteredItems.length} of {bookingItems.length} bookings
          </p>
          <div className="flex items-center space-x-2">
            <Badge className="bg-green-100 text-green-700">
              <Check className="w-3 h-3 mr-1" />
              Available
            </Badge>
            <Badge variant="outline" className="text-gray-500">
              <Clock className="w-3 h-3 mr-1" />
              Booked
            </Badge>
          </div>
        </div>

        {/* Booking Items Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => (
            <Card key={item.id} className="group hover:shadow-lg transition-all duration-300 border-0 overflow-hidden">
              <div className="h-48 bg-gradient-to-br from-indigo-100 to-purple-100 relative">
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-6xl">{getTypeIcon(item.type)}</span>
                </div>
                <div className="absolute top-3 left-3">
                  <Badge className={getTypeColor(item.type)}>
                    {item.type.charAt(0).toUpperCase() + item.type.slice(1)}
                  </Badge>
                </div>
                <div className="absolute top-3 right-3">
                  <Badge className={item.availability ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}>
                    {item.availability ? 'Available' : 'Booked'}
                  </Badge>
                </div>
              </div>
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold text-gray-800 group-hover:text-indigo-600 transition-colors">
                    {item.name}
                  </h3>
                  <div className="flex items-center text-sm text-gray-500">
                    <Star className="w-4 h-4 text-yellow-500 mr-1" />
                    {item.rating}
                  </div>
                </div>
                <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                  {item.description}
                </p>
                <div className="flex items-center text-sm text-gray-500 mb-3">
                  <MapPin className="w-3 h-3 mr-1" />
                  <span>{item.location}</span>
                  {item.duration && (
                    <>
                      <Clock className="w-3 h-3 ml-3 mr-1" />
                      <span>{item.duration}</span>
                    </>
                  )}
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-2xl font-bold text-indigo-600">₹{item.price}</p>
                    <p className="text-xs text-gray-500">per {item.type === 'hotel' ? 'night' : 'person'}</p>
                  </div>
                  <Button
                    onClick={() => handleBooking(item)}
                    disabled={!item.availability}
                    className={item.availability 
                      ? "bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700"
                      : "bg-gray-300 cursor-not-allowed"
                    }
                  >
                    {item.availability ? 'Book Now' : 'Unavailable'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Booking Dialog */}
        <Dialog open={showBookingDialog} onOpenChange={setShowBookingDialog}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Complete Your Booking</DialogTitle>
              <DialogDescription>
                {selectedItem?.name} - {selectedItem?.location}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Booking Summary</h4>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Item:</span>
                    <span>{selectedItem?.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Location:</span>
                    <span>{selectedItem?.location}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Price per person:</span>
                    <span>₹{selectedItem?.price}</span>
                  </div>
                  <div className="flex justify-between font-semibold pt-2 border-t">
                    <span>Total:</span>
                    <span className="text-indigo-600">₹{selectedItem ? selectedItem.price * parseInt(bookingDetails.guests) : 0}</span>
                  </div>
                </div>
              </div>
              
              <div>
                <label className="text-sm font-medium">Date</label>
                <Input
                  type="date"
                  value={bookingDetails.date}
                  onChange={(e) => setBookingDetails({ ...bookingDetails, date: e.target.value })}
                  required
                />
              </div>
              
              <div>
                <label className="text-sm font-medium">Number of Guests</label>
                <Select value={bookingDetails.guests} onValueChange={(value) => setBookingDetails({ ...bookingDetails, guests: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 Guest</SelectItem>
                    <SelectItem value="2">2 Guests</SelectItem>
                    <SelectItem value="3">3 Guests</SelectItem>
                    <SelectItem value="4">4 Guests</SelectItem>
                    <SelectItem value="5">5+ Guests</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="text-sm font-medium">Special Requests (optional)</label>
                <Input
                  placeholder="Any special requirements..."
                  value={bookingDetails.specialRequests}
                  onChange={(e) => setBookingDetails({ ...bookingDetails, specialRequests: e.target.value })}
                />
              </div>
              
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setShowBookingDialog(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={confirmBooking}
                  className="bg-gradient-to-r from-indigo-500 to-purple-600"
                  disabled={!bookingDetails.date}
                >
                  Confirm Booking
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}