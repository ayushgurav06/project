import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { sendEmail } from '@/lib/email'

export async function POST(request: NextRequest) {
  try {
    const { 
      itemName, 
      itemType, 
      price, 
      location, 
      stateName, 
      date, 
      guests, 
      duration, 
      specialRequests, 
      userEmail, 
      userName 
    } = await request.json()

    if (!itemName || !price || !userEmail || !userName) {
      return NextResponse.json(
        { error: 'Missing required booking information' },
        { status: 400 }
      )
    }

    // Calculate total price
    const totalPrice = price * parseInt(guests)

    // Create booking record
    const booking = await db.booking.create({
      data: {
        itemType,
        itemName,
        price: totalPrice,
        status: 'confirmed',
        userId: 'user-1', // In a real app, this would come from authentication
      }
    })

    // Create payment record
    const payment = await db.payment.create({
      data: {
        userId: 'user-1',
        amount: totalPrice,
        transactionId: `TOUR${Date.now()}`,
        status: 'completed',
        bookingId: booking.id
      }
    })

    // Send booking confirmation email
    try {
      await sendEmail(userEmail, 'bookingConfirmation', {
        userName,
        userEmail,
        itemName,
        itemType,
        location,
        stateName,
        date,
        guests,
        duration,
        specialRequests,
        totalPrice
      })
      console.log(`Booking confirmation email sent to ${userEmail}`)
    } catch (emailError) {
      console.error('Failed to send booking confirmation email:', emailError)
      // Continue even if email fails
    }

    return NextResponse.json({
      message: 'Booking confirmed successfully',
      booking,
      payment,
      transactionId: payment.transactionId
    })

  } catch (error) {
    console.error('Booking error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'User ID is required' },
        { status: 400 }
      )
    }

    const bookings = await db.booking.findMany({
      where: { userId },
      include: {
        payment: true
      },
      orderBy: {
        createdAt: 'desc'
      }
    })

    return NextResponse.json(bookings)

  } catch (error) {
    console.error('Error fetching bookings:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}