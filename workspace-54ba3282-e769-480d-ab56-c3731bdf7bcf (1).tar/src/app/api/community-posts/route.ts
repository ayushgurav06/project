import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const destination = searchParams.get('destination')
    const travelInterest = searchParams.get('travelInterest')
    const limit = parseInt(searchParams.get('limit') || '10')

    const where: any = {}
    if (destination) where.destination = { contains: destination, mode: 'insensitive' }
    if (travelInterest) where.travelInterest = { contains: travelInterest, mode: 'insensitive' }

    const communityPosts = await db.communityPost.findMany({
      where,
      include: {
        author: {
          select: {
            id: true,
            name: true,
            email: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      },
      take: limit
    })

    return NextResponse.json(communityPosts)

  } catch (error) {
    console.error('Error fetching community posts:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const { title, content, destination, travelInterest, authorId } = await request.json()

    if (!title || !content || !authorId) {
      return NextResponse.json(
        { error: 'Title, content, and authorId are required' },
        { status: 400 }
      )
    }

    const communityPost = await db.communityPost.create({
      data: {
        title,
        content,
        destination,
        travelInterest,
        authorId
      },
      include: {
        author: {
          select: {
            id: true,
            name: true,
            email: true
          }
        }
      }
    })

    return NextResponse.json({
      message: 'Community post created successfully',
      communityPost
    })

  } catch (error) {
    console.error('Error creating community post:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}