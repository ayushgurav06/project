import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export async function POST(request: NextRequest) {
  try {
    const { message, userId } = await request.json()

    if (!message) {
      return NextResponse.json(
        { error: 'Message is required' },
        { status: 400 }
      )
    }

    const zai = await ZAI.create()

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: `You are a helpful AI travel assistant for Tourism India. You help users plan their trips to India, suggest destinations, recommend best times to visit, suggest local food specialties, and provide cultural insights. Always be enthusiastic about Indian tourism and provide practical, helpful advice. If you don't know something, be honest and suggest they check with local tourism offices.`
        },
        {
          role: 'user',
          content: message
        }
      ],
      temperature: 0.7,
      max_tokens: 500
    })

    const aiResponse = completion.choices[0]?.message?.content || 'I apologize, but I couldn\'t process your request right now.'

    // Here you could save the conversation to database if needed
    // await saveConversation(userId, message, aiResponse)

    return NextResponse.json({
      response: aiResponse
    })

  } catch (error) {
    console.error('AI Assistant error:', error)
    return NextResponse.json(
      { error: 'Failed to get AI response' },
      { status: 500 }
    )
  }
}