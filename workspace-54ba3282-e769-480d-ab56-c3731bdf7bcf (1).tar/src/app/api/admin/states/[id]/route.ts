import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// DELETE /api/admin/states/[id] - Delete state
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params

    // Delete related famous places first
    await db.famousPlace.deleteMany({
      where: { stateId: id }
    })

    // Delete related local posts
    await db.localPost.deleteMany({
      where: { stateId: id }
    })

    // Delete the state
    await db.state.delete({
      where: { id }
    })

    return NextResponse.json({
      message: 'State deleted successfully'
    })

  } catch (error) {
    console.error('Error deleting state:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}