import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// DELETE /api/admin/users/[id] - Delete user
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params

    // Don't allow deleting the main admin
    if (id === 'cmhhgzpb30000immeowk3303f') {
      return NextResponse.json(
        { error: 'Cannot delete main admin user' },
        { status: 403 }
      )
    }

    // Delete user
    await db.user.delete({
      where: { id }
    })

    return NextResponse.json({
      message: 'User deleted successfully'
    })

  } catch (error) {
    console.error('Error deleting user:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}