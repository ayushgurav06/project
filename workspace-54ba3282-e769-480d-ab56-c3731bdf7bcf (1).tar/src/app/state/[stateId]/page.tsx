'use client'

import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { ArrowLeft, MapPin, Calendar, Users, Star, Clock, CreditCard, Search, Filter, Heart, Share2, Check } from 'lucide-react'
import Link from 'next/link'
import { toast } from 'sonner'

interface StateBooking {
  id: string
  name: string
  description: string
  image: string
  capital: string
  bestTimeToVisit: string
  culturalEvents: string[]
}

interface BookingItem {
  id: string
  name: string
  type: 'hotel' | 'guide' | 'experience'
  price: number
  location: string
  rating: number
  duration?: string
  availability: boolean
  description: string
  stateId: string
}

const stateData: Record<string, StateBooking> = {
  rajasthan: {
    id: 'rajasthan',
    name: 'Rajasthan',
    description: 'Land of Kings - Desert forts, palaces, and vibrant culture',
    image: '/states/rajasthan.jpg',
    capital: 'Jaipur',
    bestTimeToVisit: 'October to March',
    culturalEvents: ['Pushkar Camel Fair', 'Desert Festival', 'Teej Festival']
  },
  kerala: {
    id: 'kerala',
    name: 'Kerala',
    description: 'God\'s Own Country - Backwaters, beaches, and Ayurveda',
    image: '/states/kerala.jpg',
    capital: 'Thiruvananthapuram',
    bestTimeToVisit: 'September to March',
    culturalEvents: ['Onam', 'Vishu', 'Thrissur Pooram']
  },
  goa: {
    id: 'goa',
    name: 'Goa',
    description: 'Beach Paradise - Sun, sand, and Portuguese heritage',
    image: '/states/goa.jpg',
    capital: 'Panaji',
    bestTimeToVisit: 'November to February',
    culturalEvents: ['Goa Carnival', 'Shigmo', 'Sao Joao']
  },
  'uttar-pradesh': {
    id: 'uttar-pradesh',
    name: 'Uttar Pradesh',
    description: 'Heart of India - Taj Mahal, Ganges, and spiritual centers',
    image: '/states/uttar-pradesh.jpg',
    capital: 'Lucknow',
    bestTimeToVisit: 'October to March',
    culturalEvents: ['Kumbh Mela', 'Taj Mahotsav', 'Buddha Purnima']
  },
  maharashtra: {
    id: 'maharashtra',
    name: 'Maharashtra',
    description: 'Land of Warriors - Mumbai caves, beaches, and Bollywood',
    image: '/states/maharashtra.jpg',
    capital: 'Mumbai',
    bestTimeToVisit: 'November to February',
    culturalEvents: ['Ganesh Chaturthi', 'Navratri', 'Ellora Festival']
  },
  'tamil-nadu': {
    id: 'tamil-nadu',
    name: 'Tamil Nadu',
    description: 'Temple State - Ancient Dravidian architecture and culture',
    image: '/states/tamil-nadu.jpg',
    capital: 'Chennai',
    bestTimeToVisit: 'November to March',
    culturalEvents: ['Pongal', 'Tamil New Year', 'Natyanjali Festival']
  },
  'himachal-pradesh': {
    id: 'himachal-pradesh',
    name: 'Himachal Pradesh',
    description: 'Land of Gods - Himalayan mountains and adventure sports',
    image: '/states/himachal-pradesh.jpg',
    capital: 'Shimla',
    bestTimeToVisit: 'March to June, September to November',
    culturalEvents: ['Kullu Dussehra', 'Shivratri Fair', 'Minjar Fair']
  },
  'west-bengal': {
    id: 'west-bengal',
    name: 'West Bengal',
    description: 'Cultural Capital - Art, literature, and colonial heritage',
    image: '/states/west-bengal.jpg',
    capital: 'Kolkata',
    bestTimeToVisit: 'October to March',
    culturalEvents: ['Durga Puja', 'Kolkata Film Festival', 'Rabindra Jayanti']
  },
  gujarat: {
    id: 'gujarat',
    name: 'Gujarat',
    description: 'Land of Legends - Gir lions, white desert, and business hub',
    image: '/states/gujarat.jpg',
    capital: 'Gandhinagar',
    bestTimeToVisit: 'November to February',
    culturalEvents: ['Navratri', 'Rann Utsav', 'International Kite Festival']
  },
  'madhya-pradesh': {
    id: 'madhya-pradesh',
    name: 'Madhya Pradesh',
    description: 'Heart of India - Wildlife, temples, and tribal culture',
    image: '/states/madhya-pradesh.jpg',
    capital: 'Bhopal',
    bestTimeToVisit: 'October to March',
    culturalEvents: ['Khajuraho Dance Festival', 'Tansen Music Festival', 'Bhagoria Haat']
  },
  karnataka: {
    id: 'karnataka',
    name: 'Karnataka',
    description: 'Silicon Valley - Gardens, palaces, and IT hub',
    image: '/states/karnataka.jpg',
    capital: 'Bengaluru',
    bestTimeToVisit: 'October to March',
    culturalEvents: ['Mysore Dasara', 'Hampi Festival', 'Karaga Festival']
  },
  delhi: {
    id: 'delhi',
    name: 'Delhi',
    description: 'Capital Territory - Mughal heritage and modern metropolis',
    image: '/states/delhi.jpg',
    capital: 'New Delhi',
    bestTimeToVisit: 'October to March',
    culturalEvents: ['India International Trade Fair', 'Qutub Festival', 'International Food Festival']
  }
}

const generateBookingItems = (stateId: string): BookingItem[] => {
  const state = stateData[stateId]
  if (!state) return []

  return [
    {
      id: `${stateId}-heritage-hotel`,
      name: `${state.name} Heritage Hotel`,
      type: 'hotel',
      price: Math.floor(Math.random() * 3000) + 2000,
      location: state.capital,
      rating: 4.5 + Math.random() * 0.5,
      availability: true,
      description: `Experience authentic ${state.name} hospitality in our heritage hotel with traditional architecture and modern amenities.`,
      stateId
    },
    {
      id: `${stateId}-city-guide`,
      name: `Local City Guide - ${state.capital}`,
      type: 'guide',
      price: Math.floor(Math.random() * 1000) + 1000,
      location: state.capital,
      rating: 4.7 + Math.random() * 0.3,
      duration: '8 hours',
      availability: true,
      description: `Expert local guide to explore ${state.capital}'s hidden gems and cultural landmarks.`,
      stateId
    },
    {
      id: `${stateId}-cultural-experience`,
      name: `${state.name} Cultural Experience`,
      type: 'experience',
      price: Math.floor(Math.random() * 2000) + 1500,
      location: state.capital,
      rating: 4.8 + Math.random() * 0.2,
      duration: '1 day',
      availability: Math.random() > 0.3,
      description: `Immerse yourself in ${state.name}'s rich culture with traditional activities, local cuisine, and cultural performances.`,
      stateId
    },
    {
      id: `${stateId}-adventure-tour`,
      name: `${state.name} Adventure Tour`,
      type: 'experience',
      price: Math.floor(Math.random() * 2500) + 2000,
      location: 'Various locations',
      rating: 4.6 + Math.random() * 0.4,
      duration: '2 days',
      availability: Math.random() > 0.2,
      description: `Exciting adventure activities showcasing the best of ${state.name}'s natural beauty and thrilling experiences.`,
      stateId
    }
  ]
}

export default function StateBookingPage() {
  const params = useParams()
  const router = useRouter()
  const [stateId] = useState(params.stateId as string)
  const [state, setState] = useState<StateBooking | null>(null)
  const [bookingItems, setBookingItems] = useState<BookingItem[]>([])
  const [filteredItems, setFilteredItems] = useState<BookingItem[]>([])
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedType, setSelectedType] = useState('all')
  const [showBookingDialog, setShowBookingDialog] = useState(false)
  const [selectedItem, setSelectedItem] = useState<BookingItem | null>(null)
  const [bookingDetails, setBookingDetails] = useState({
    date: '',
    guests: '1',
    specialRequests: ''
  })

  useEffect(() => {
    const stateInfo = stateData[stateId]
    if (stateInfo) {
      setState(stateInfo)
      const items = generateBookingItems(stateId)
      setBookingItems(items)
      setFilteredItems(items)
    } else {
      router.push('/home')
    }
  }, [stateId, router])

  useEffect(() => {
    let filtered = bookingItems

    if (searchTerm) {
      filtered = filtered.filter(item =>
        item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.location.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    if (selectedType !== 'all') {
      filtered = filtered.filter(item => item.type === selectedType)
    }

    setFilteredItems(filtered)
  }, [bookingItems, searchTerm, selectedType])

  const handleBooking = (item: BookingItem) => {
    setSelectedItem(item)
    setShowBookingDialog(true)
  }

  const confirmBooking = async () => {
    if (selectedItem && state) {
      const totalPrice = selectedItem.price * parseInt(bookingDetails.guests)
      const guestText = parseInt(bookingDetails.guests) === 1 ? '1 guest' : `${bookingDetails.guests} guests`
      
      try {
        // Call booking API
        const response = await fetch('/api/bookings', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            itemName: selectedItem.name,
            itemType: selectedItem.type,
            price: selectedItem.price,
            location: selectedItem.location,
            stateName: state.name,
            date: bookingDetails.date,
            guests: bookingDetails.guests,
            duration: selectedItem.duration,
            specialRequests: bookingDetails.specialRequests,
            userEmail: 'user@example.com', // In a real app, this would come from authentication
            userName: 'Demo User' // In a real app, this would come from authentication
          }),
        })

        const data = await response.json()

        if (response.ok) {
          // Show success notification
          toast.success('🎉 Booking Confirmed!', {
            description: `${selectedItem.name} in ${state.name} for ${guestText} on ${bookingDetails.date}`,
            duration: 6000,
          })
          
          // Show detailed booking confirmation
          toast.success('📧 Booking Details Sent!', {
            description: `Transaction ID: ${data.transactionId} | Total: ₹${totalPrice} | Email: user@example.com`,
            duration: 8000,
          })
          
          // Show next steps notification
          toast.info('✅ Next Steps', {
            description: 'Check your email for complete booking details. Save this transaction ID for future reference.',
            duration: 6000,
          })
          
          // Show final confirmation message
          toast.success('🎊 Booking Successful!', {
            description: 'Your adventure in India is confirmed. We\'ll send you reminders and updates!',
            duration: 5000,
          })
          
          setShowBookingDialog(false)
          setBookingDetails({ date: '', guests: '1', specialRequests: '' })
        } else {
          toast.error('Booking failed', {
            description: data.error || 'Please try again.',
            duration: 4000,
          })
        }
      } catch (error) {
        toast.error('Network error', {
          description: 'Please check your connection and try again.',
          duration: 4000,
        })
      }
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'hotel':
        return '🏨'
      case 'guide':
        return '👤'
      case 'experience':
        return '🎯'
      default:
        return '📍'
    }
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'hotel':
        return 'bg-blue-100 text-blue-700'
      case 'guide':
        return 'bg-green-100 text-green-700'
      case 'experience':
        return 'bg-purple-100 text-purple-700'
      default:
        return 'bg-gray-100 text-gray-700'
    }
  }

  if (!state) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading state information...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-green-50">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-orange-200 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/home" className="inline-flex items-center text-orange-600 hover:text-orange-700">
                <ArrowLeft className="w-5 h-5 mr-2" />
                Back to Home
              </Link>
              <div className="flex items-center space-x-2">
                <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-green-600 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-xl">🇮🇳</span>
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-800">{state.name} Bookings</h1>
                  <p className="text-sm text-gray-600">Hotels, guides & experiences</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* State Hero Section */}
      <section className="relative h-64 overflow-hidden">
        <img 
          src={state.image} 
          alt={state.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent"></div>
        <div className="absolute bottom-6 left-6 text-white">
          <h2 className="text-3xl font-bold mb-2">{state.name}</h2>
          <p className="text-lg mb-1">{state.description}</p>
          <div className="flex items-center space-x-4 text-sm">
            <div className="flex items-center">
              <MapPin className="w-4 h-4 mr-1" />
              <span>Capital: {state.capital}</span>
            </div>
            <div className="flex items-center">
              <Calendar className="w-4 h-4 mr-1" />
              <span>Best Time: {state.bestTimeToVisit}</span>
            </div>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-6">
        {/* Cultural Events */}
        <Card className="mb-6 border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="text-lg">Cultural Events</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {state.culturalEvents.map((event, index) => (
                <Badge key={index} className="bg-orange-100 text-orange-700">
                  {event}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Search and Filter */}
        <Card className="mb-6 border-0 shadow-sm">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search hotels, guides, experiences..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Filter className="w-4 h-4 text-gray-500" />
                <Select value={selectedType} onValueChange={setSelectedType}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="hotel">Hotels</SelectItem>
                    <SelectItem value="guide">Guides</SelectItem>
                    <SelectItem value="experience">Experiences</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results Count */}
        <div className="mb-4 flex items-center justify-between">
          <p className="text-gray-600">
            Showing {filteredItems.length} of {bookingItems.length} bookings in {state.name}
          </p>
        </div>

        {/* Booking Items Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => (
            <Card key={item.id} className="group hover:shadow-lg transition-all duration-300 border-0 overflow-hidden">
              <div className="h-48 bg-gradient-to-br from-indigo-100 to-purple-100 relative">
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-6xl">{getTypeIcon(item.type)}</span>
                </div>
                <div className="absolute top-3 left-3">
                  <Badge className={getTypeColor(item.type)}>
                    {item.type.charAt(0).toUpperCase() + item.type.slice(1)}
                  </Badge>
                </div>
                <div className="absolute top-3 right-3">
                  <Badge className={item.availability ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}>
                    {item.availability ? 'Available' : 'Booked'}
                  </Badge>
                </div>
              </div>
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold text-gray-800 group-hover:text-indigo-600 transition-colors">
                    {item.name}
                  </h3>
                  <div className="flex items-center text-sm text-gray-500">
                    <Star className="w-4 h-4 text-yellow-500 mr-1" />
                    {item.rating.toFixed(1)}
                  </div>
                </div>
                <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                  {item.description}
                </p>
                <div className="flex items-center text-sm text-gray-500 mb-3">
                  <MapPin className="w-3 h-3 mr-1" />
                  <span>{item.location}</span>
                  {item.duration && (
                    <>
                      <Clock className="w-3 h-3 ml-3 mr-1" />
                      <span>{item.duration}</span>
                    </>
                  )}
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-2xl font-bold text-indigo-600">₹{item.price}</p>
                    <p className="text-xs text-gray-500">per {item.type === 'hotel' ? 'night' : 'person'}</p>
                  </div>
                  <Button
                    onClick={() => handleBooking(item)}
                    disabled={!item.availability}
                    className={item.availability 
                      ? "bg-gradient-to-r from-orange-500 to-green-600 hover:from-orange-600 hover:to-green-700"
                      : "bg-gray-300 cursor-not-allowed"
                    }
                  >
                    {item.availability ? 'Book Now' : 'Unavailable'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Booking Dialog */}
        <Dialog open={showBookingDialog} onOpenChange={setShowBookingDialog}>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Complete Your Booking</DialogTitle>
              <DialogDescription>
                {selectedItem?.name} - {state.name}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold mb-2">Booking Summary</h4>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <strong>Item:</strong>
                    <span>{selectedItem?.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <strong>Location:</strong>
                    <span>{selectedItem?.location}</span>
                  </div>
                  <div className="flex justify-between">
                    <strong>Date:</strong>
                    <span>{bookingDetails.date}</span>
                  </div>
                  <div className="flex justify-between">
                    <strong>Guests:</strong>
                    <span>{bookingDetails.guests}</span>
                  </div>
                  <div className="flex justify-between">
                    <strong>Duration:</strong>
                    <span>{selectedItem?.duration || 'As per booking'}</span>
                  </div>
                  {bookingDetails.specialRequests && (
                    <div className="flex justify-between">
                      <strong>Special Requests:</strong>
                      <span>{bookingDetails.specialRequests}</span>
                    </div>
                  )}
                  <div className="flex justify-between font-semibold pt-2 border-t">
                    <strong>Total:</strong>
                    <span className="text-indigo-600">₹{selectedItem ? selectedItem.price * parseInt(bookingDetails.guests) : 0}</span>
                  </div>
                </div>
              </div>
              
              <div>
                <label className="text-sm font-medium">Date</label>
                <Input
                  type="date"
                  value={bookingDetails.date}
                  onChange={(e) => setBookingDetails({ ...bookingDetails, date: e.target.value })}
                  required
                />
              </div>
              
              <div>
                <label className="text-sm font-medium">Number of Guests</label>
                <Select value={bookingDetails.guests} onValueChange={(value) => setBookingDetails({ ...bookingDetails, guests: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 Guest</SelectItem>
                    <SelectItem value="2">2 Guests</SelectItem>
                    <SelectItem value="3">3 Guests</SelectItem>
                    <SelectItem value="4">4 Guests</SelectItem>
                    <SelectItem value="5">5+ Guests</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="text-sm font-medium">Special Requests (optional)</label>
                <Input
                  placeholder="Any special requirements..."
                  value={bookingDetails.specialRequests}
                  onChange={(e) => setBookingDetails({ ...bookingDetails, specialRequests: e.target.value })}
                />
              </div>
              
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setShowBookingDialog(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={confirmBooking}
                  className="bg-gradient-to-r from-indigo-500 to-purple-600"
                  disabled={!bookingDetails.date}
                >
                  Confirm Booking
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}