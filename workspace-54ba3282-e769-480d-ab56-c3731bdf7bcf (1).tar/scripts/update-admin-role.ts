import { db } from '../src/lib/db'

async function updateAdminRole() {
  try {
    // Update existing user to admin role
    const user = await db.user.update({
      where: { email: 'ayushgurav0608@gmail.com' },
      data: { role: 'admin' }
    })

    console.log('User role updated to admin successfully!')
    console.log('Email:', user.email)
    console.log('Name:', user.name)
    console.log('Role:', user.role)
    console.log('User ID:', user.id)

  } catch (error) {
    console.error('Error updating user role:', error)
  }
}

updateAdminRole()