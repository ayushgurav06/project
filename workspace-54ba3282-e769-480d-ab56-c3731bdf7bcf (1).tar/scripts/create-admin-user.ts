import { db } from '../src/lib/db'
import bcrypt from 'bcryptjs'

async function createAdminUser() {
  try {
    // Check if admin user already exists
    const existingUser = await db.user.findUnique({
      where: { email: 'ayushgurav0608@gmail.com' }
    })

    if (existingUser) {
      console.log('Admin user already exists!')
      console.log('Email:', existingUser.email)
      console.log('Name:', existingUser.name)
      console.log('Role:', existingUser.role)
      return
    }

    // Hash password
    const hashedPassword = await bcrypt.hash('admin123', 10)

    // Create admin user
    const user = await db.user.create({
      data: {
        name: 'Ayush Gurav',
        email: 'ayushgurav0608@gmail.com',
        password: hashedPassword,
        role: 'admin'
      }
    })

    console.log('Admin user created successfully!')
    console.log('Email: ayushgurav0608@gmail.com')
    console.log('Password: admin123')
    console.log('Name: Ayush Gurav')
    console.log('Role: admin')
    console.log('User ID:', user.id)

  } catch (error) {
    console.error('Error creating admin user:', error)
  }
}

createAdminUser()