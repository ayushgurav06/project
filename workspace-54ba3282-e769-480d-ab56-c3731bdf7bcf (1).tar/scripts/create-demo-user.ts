import { db } from '../src/lib/db'
import bcrypt from 'bcryptjs'

async function createDemoUser() {
  try {
    // Check if demo user already exists
    const existingUser = await db.user.findUnique({
      where: { email: 'demo@tourism.com' }
    })

    if (existingUser) {
      console.log('Demo user already exists!')
      return
    }

    // Hash password
    const hashedPassword = await bcrypt.hash('demo123', 10)

    // Create demo user
    const user = await db.user.create({
      data: {
        name: 'Demo User',
        email: 'demo@tourism.com',
        password: hashedPassword,
        role: 'user'
      }
    })

    console.log('Demo user created successfully!')
    console.log('Email: demo@tourism.com')
    console.log('Password: demo123')

  } catch (error) {
    console.error('Error creating demo user:', error)
  }
}

createDemoUser()