import { db } from '../src/lib/db'

async function updateStateImages() {
  try {
    // Update state images
    await db.state.updateMany({
      where: { name: 'Rajasthan' },
      data: { image: '/states/rajasthan.jpg' }
    })

    await db.state.updateMany({
      where: { name: 'Kerala' },
      data: { image: '/states/kerala.jpg' }
    })

    await db.state.updateMany({
      where: { name: 'Goa' },
      data: { image: '/states/goa.jpg' }
    })

    console.log('State images updated successfully!')
  } catch (error) {
    console.error('Error updating state images:', error)
  }
}

updateStateImages()