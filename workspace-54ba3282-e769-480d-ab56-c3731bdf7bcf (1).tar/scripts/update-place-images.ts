import { db } from '../src/lib/db'

async function updatePlaceImages() {
  try {
    // Update famous place images
    await db.famousPlace.updateMany({
      where: { name: 'Hawa Mahal' },
      data: { image: '/states/rajasthan.jpg' }
    })

    await db.famousPlace.updateMany({
      where: { name: 'Amber Fort' },
      data: { image: '/places/amber-fort.jpg' }
    })

    await db.famousPlace.updateMany({
      where: { name: 'Alleppey Backwaters' },
      data: { image: '/places/alleppey-backwaters.jpg' }
    })

    await db.famousPlace.updateMany({
      where: { name: 'Baga Beach' },
      data: { image: '/places/baga-beach.jpg' }
    })

    console.log('Famous place images updated successfully!')
  } catch (error) {
    console.error('Error updating place images:', error)
  }
}

updatePlaceImages()