import { db } from '../src/lib/db'

async function seedData() {
  try {
    // Create states
    const states = await Promise.all([
      db.state.create({
        data: {
          name: 'Rajasthan',
          description: 'Land of Kings - Desert forts, palaces, and vibrant culture',
          image: '/api/placeholder?width=400&height=300',
          capital: 'Jaipur',
          bestTimeToVisit: 'October to March',
          culturalEvents: JSON.stringify(['Pushkar Camel Fair', 'Desert Festival', 'Teej Festival'])
        }
      }),
      db.state.create({
        data: {
          name: 'Kerala',
          description: 'God\'s Own Country - Backwaters, beaches, and Ayurveda',
          image: '/api/placeholder?width=400&height=300',
          capital: 'Thiruvananthapuram',
          bestTimeToVisit: 'September to March',
          culturalEvents: JSON.stringify(['Onam', 'Vishu', 'Thrissur Pooram'])
        }
      }),
      db.state.create({
        data: {
          name: 'Goa',
          description: 'Beach Paradise - Sun, sand, and Portuguese heritage',
          image: '/api/placeholder?width=400&height=300',
          capital: 'Panaji',
          bestTimeToVisit: 'November to February',
          culturalEvents: JSON.stringify(['Goa Carnival', 'Shigmo', 'Sao Joao'])
        }
      })
    ])

    // Create famous places for each state
    await Promise.all([
      // Rajasthan places
      db.famousPlace.createMany({
        data: [
          {
            name: 'Hawa Mahal',
            description: 'The Palace of Winds, a stunning pink sandstone structure',
            image: '/api/placeholder?width=400&height=300',
            location: 'Jaipur',
            bookingUrl: 'https://example.com/hawa-mahal',
            stateId: states[0].id
          },
          {
            name: 'Amber Fort',
            description: 'Majestic hilltop fortress with beautiful architecture',
            image: '/api/placeholder?width=400&height=300',
            location: 'Amber',
            bookingUrl: 'https://example.com/amber-fort',
            stateId: states[0].id
          }
        ]
      }),
      // Kerala places
      db.famousPlace.createMany({
        data: [
          {
            name: 'Alleppey Backwaters',
            description: 'Serene network of lagoons and lakes',
            image: '/api/placeholder?width=400&height=300',
            location: 'Alleppey',
            bookingUrl: 'https://example.com/alleppey-backwaters',
            stateId: states[1].id
          },
          {
            name: 'Munnar Tea Gardens',
            description: 'Lush green tea plantations in the Western Ghats',
            image: '/api/placeholder?width=400&height=300',
            location: 'Munnar',
            bookingUrl: 'https://example.com/munnar-tea-gardens',
            stateId: states[1].id
          }
        ]
      }),
      // Goa places
      db.famousPlace.createMany({
        data: [
          {
            name: 'Baga Beach',
            description: 'Popular beach with water sports and vibrant nightlife',
            image: '/api/placeholder?width=400&height=300',
            location: 'North Goa',
            bookingUrl: 'https://example.com/baga-beach',
            stateId: states[2].id
          },
          {
            name: 'Basilica of Bom Jesus',
            description: 'UNESCO World Heritage site with Portuguese architecture',
            image: '/api/placeholder?width=400&height=300',
            location: 'Old Goa',
            bookingUrl: 'https://example.com/basilica-bom-jesus',
            stateId: states[2].id
          }
        ]
      })
    ])

    console.log('Sample data seeded successfully!')
  } catch (error) {
    console.error('Error seeding data:', error)
  }
}

seedData()